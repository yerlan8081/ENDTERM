package com.example.midterm.mapper;

import com.example.midterm.dto.EntityFileDto;
import com.example.midterm.model.FileEntity;
import org.mapstruct.Mapper;

import java.util.List;

/*
 *@author Yerlan
 *@create 2025-10-17 16:42
 */
@Mapper(componentModel = "spring")
public interface EntityFileMapper {

    EntityFileDto toDto(FileEntity file);
    FileEntity toEntity(EntityFileDto dto);
    List<EntityFileDto> toDtoList(List<FileEntity> fileList);

}
