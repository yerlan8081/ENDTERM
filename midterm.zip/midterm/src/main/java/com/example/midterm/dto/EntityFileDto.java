package com.example.midterm.dto;

import java.time.LocalDateTime;

/*
 *@author Yerlan
 *@create 2025-10-17 16:42
 */
public class EntityFileDto {

    private Long id;
    private String fileName;
    private String originalName;
    private long size;
    private LocalDateTime addedTime;
    private String mimeType;

}
