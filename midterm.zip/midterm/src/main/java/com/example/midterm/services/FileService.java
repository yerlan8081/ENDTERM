package com.example.midterm.services;

import com.example.midterm.dto.EntityFileDto;
import com.example.midterm.mapper.EntityFileMapper;
import com.example.midterm.model.FileEntity;
import com.example.midterm.repository.EntityFileRepository;
import io.minio.GetObjectArgs;
import io.minio.MinioClient;
import io.minio.PutObjectArgs;
import lombok.RequiredArgsConstructor;
import org.apache.commons.codec.digest.DigestUtils;
import org.apache.commons.compress.utils.IOUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;

import java.io.InputStream;
import java.util.List;

/*
 *@author Yerlan
 *@create 2025-10-17 16:44
 */
@Service
@RequiredArgsConstructor
public class FileService {

    private final MinioClient minioClient;

    @Value("${minio.bucket}")
    private String bucket;

    private final EntityFileRepository attachmentFileRepository;

    private final EntityFileMapper attachmentFileMapper;

    public String uploadFile(MultipartFile file) {

        FileEntity attachmentFile = new FileEntity();
        attachmentFile.setSize(file.getSize());
        attachmentFile.setOriginalName(file.getOriginalFilename());
        attachmentFile.setMimeType(file.getContentType());

        attachmentFile = attachmentFileRepository.save(attachmentFile);

        String extension = StringUtils.getFilenameExtension(file.getOriginalFilename());

        String fileName = convertToSha1("Yerlan_" + attachmentFile.getId());
        if (extension != null && !extension.isEmpty()) {
            fileName = fileName + "." + extension;
        }

        try {
            minioClient.putObject(
                    PutObjectArgs
                            .builder()
                            .bucket(bucket)
                            .object(fileName)
                            .stream(file.getInputStream(), file.getSize(), -1)
                            .contentType(file.getContentType())
                            .build()
            );

            // Сохраняем имя файла в MinIO
            attachmentFile.setFileName(fileName);
            attachmentFileRepository.save(attachmentFile);

            return fileName;

        } catch (Exception e) {
            e.printStackTrace();
        }

        return null;
    }

    public ResponseEntity<ByteArrayResource> downloadFile(String fileName) {

        FileEntity attachmentFile = attachmentFileRepository.findByFileName(fileName);

        if (attachmentFile != null) {
            try {
                GetObjectArgs getObjectArgs = GetObjectArgs
                        .builder()
                        .bucket(bucket)
                        .object(fileName)
                        .build();

                InputStream stream = minioClient.getObject(getObjectArgs);
                byte[] byteArray = IOUtils.toByteArray(stream);
                stream.close();

                ByteArrayResource resource = new ByteArrayResource(byteArray);

                HttpHeaders headers = new HttpHeaders();
                headers.add(HttpHeaders.CONTENT_DISPOSITION,
                        "attachment; filename=\"" + attachmentFile.getOriginalName() + "\"");
                headers.add(HttpHeaders.CONTENT_TYPE, attachmentFile.getMimeType());

                return ResponseEntity
                        .ok()
                        .headers(headers)
                        .contentLength(attachmentFile.getSize())
                        .body(resource);

            } catch (Exception e) {
                e.printStackTrace();
                return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
            }
        }

        return ResponseEntity.notFound().build();
    }

    private String convertToSha1(String plainText) {
        return DigestUtils.sha1Hex(plainText);
    }

    public List<EntityFileDto> getEntitys() {
        return attachmentFileMapper.toDtoList(attachmentFileRepository.findAll());
    }

    public EntityFileDto getEntity(Long id) {
        return attachmentFileMapper.toDto(attachmentFileRepository.findById(id).orElse(null));
    }

    public EntityFileDto getEntityByFileName(String fileName) {
        return attachmentFileMapper.toDto(attachmentFileRepository.findByFileName(fileName));
    }

}
