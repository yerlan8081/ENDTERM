package com.example.midterm.repository;

import com.example.midterm.model.FileEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

/*
 *@author Yerlan
 *@create 2025-10-17 16:44
 */
@Repository
public interface EntityFileRepository extends JpaRepository<FileEntity, Long> {

    FileEntity findByFileName(String fileName);

}
