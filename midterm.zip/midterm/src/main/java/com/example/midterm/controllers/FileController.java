package com.example.midterm.controllers;

import com.example.midterm.dto.EntityFileDto;
import com.example.midterm.services.FileService;
import lombok.RequiredArgsConstructor;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

/*
 *@author Yerlan
 *@create 2025-10-17 16:37
 */
@RestController
@RequestMapping(value = "/file")
@RequiredArgsConstructor
public class FileController {

    private final FileService fileService;

    @PostMapping(value = "/upload")
    public String upload(@RequestParam("file") MultipartFile file) {
        return fileService.uploadFile(file);
    }

    @GetMapping(value = "/download/{fileName}")
    public ResponseEntity<ByteArrayResource> downloadFile(@PathVariable(name = "fileName") String fileName) {
        return fileService.downloadFile(fileName);
    }

    @GetMapping
    public List<EntityFileDto> getEntitys() {
        return fileService.getEntitys();
    }

    @GetMapping(value = "/{id}")
    public EntityFileDto getEntity(@PathVariable(name = "id") Long id) {
        return fileService.getEntity(id);
    }

    @GetMapping(value = "/filename/{fileName}")
    public EntityFileDto getEntity(@PathVariable(name = "fileName") String fileName) {
        return fileService.getEntityByFileName(fileName);
    }
}
