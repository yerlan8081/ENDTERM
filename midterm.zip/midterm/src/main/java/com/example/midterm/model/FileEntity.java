package com.example.midterm.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

/*
 *@author Yerlan
 *@create 2025-10-17 16:40
 */
@Entity
@Table(name = "t_attachments")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class FileEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String originalName;
    private String mimeType;
    private long size;

    @Column(unique = true)
    private String fileName;

    private LocalDateTime addedTime;

    @PrePersist
    private void setTime(){
        addedTime = LocalDateTime.now();
    }

}
